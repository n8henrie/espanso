Obsolete "tech notes" directory
-------------------------------

This directory used to contain "technical notes" for wxWidgets contributors,
but is not used any longer, this file only exists to point you to the "HOW TO"
guides in `docs/contributing` directory which are still relevant, if you're
looking for something that used to be here.
