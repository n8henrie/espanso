
  Welcome to wxWidgets/Wine

You have downloaded the WINE port of the wxWidgets GUI library.

Information on how to install can be found in the file
install.txt.

When you run into problems, please read the install.txt and
follow those instructions. If you still don't have any success,
please send a bug report to one of our mailing lists (see
my homepage) INCLUDING A DESCRIPTION OF YOUR SYSTEM AND
YOUR PROBLEM, SUCH AS YOUR VERSION OF THE WINE SOURCES, WHAT
DISTRIBUTION YOU USE AND WHAT ERROR WAS REPORTED.

Please send problems concerning installation, feature requests,
bug reports or comments to the wxWidgets users list. Information
on how to subscribe is available from my homepage.

wxWidgets/Wine doesn't come with any guarantee whatsoever. It might
crash your harddisk or destroy your monitor. It doesn't claim to be
suitable for any special or general purpose.

